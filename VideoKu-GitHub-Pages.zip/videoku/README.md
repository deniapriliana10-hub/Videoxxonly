# VideoKu — YouTube-style video website

Paket ini berisi frontend statis untuk GitHub Pages dan API backend Cloudflare Worker. File video tidak diunggah ke GitHub; website memutar URL CDN MP4 eksternal. Metadata disimpan di `data/videos.json` pada repository GitHub.

## Isi paket

- `index.html` — beranda, pencarian, filter kategori, kartu video.
- `watch.html` — halaman pemutar video dan video terkait.
- `admin.html` — login admin dan formulir tambah video.
- `assets/` — CSS, JavaScript, logo, placeholder, dan konfigurasi API.
- `data/videos.json` — metadata video (awalnya array kosong).
- `worker/` — Cloudflare Worker API dengan login admin, token HMAC berumur 6 jam, validasi input, dan penulisan file GitHub lewat GitHub Contents API.

## Bagian 1 — Buat repository GitHub

1. Buat repository baru bernama `videoku` (atau nama lain, tetapi sesuaikan `GITHUB_REPO` nanti).
2. Unggah seluruh isi folder paket ini ke **root repository**. Pastikan `index.html` berada di root dan folder `data/` juga ada di root.
3. Commit perubahan ke branch `main`.
4. Buka **Settings → Pages**. Pada bagian Build and deployment, pilih **Deploy from a branch**, branch `main`, folder `/(root)`, lalu Save.
5. Tunggu sampai GitHub Pages aktif. Alamat umumnya `https://USERNAME.github.io/videoku/`.

Jangan menghapus `data/videos.json`. Worker memerlukan file tersebut untuk membaca dan menambahkan metadata.

## Bagian 2 — Buat GitHub token untuk backend saja

1. Di GitHub buka **Settings → Developer settings → Personal access tokens → Fine-grained tokens**.
2. Buat token yang hanya memiliki akses ke repository VideoKu.
3. Beri **Repository permissions → Contents: Read and write**. Metadata biasanya otomatis read-only. Jangan memberi akses ke repository lain jika tidak diperlukan.
4. Simpan token sementara untuk langkah deployment Worker. Token ini **jangan pernah** ditulis ke HTML, JavaScript frontend, `config.js`, atau repository.

Token GitHub hanya dipasang sebagai secret di Cloudflare Worker. Gunakan masa berlaku token yang wajar dan rotasi jika bocor.

## Bagian 3 — Deploy Cloudflare Worker

Persyaratan: Node.js dan npm terpasang di komputer, serta akun Cloudflare.

1. Buka terminal/Command Prompt, lalu masuk ke folder `worker` dalam paket ini.
2. Jalankan:

   ```bash
   npm install
   npx wrangler login
   ```

3. Edit `worker/wrangler.toml`:
   - `SITE_ORIGIN`: untuk URL `https://USERNAME.github.io/videoku/`, isi **origin saja**, yaitu `https://USERNAME.github.io` (tanpa `/videoku/` dan tanpa slash akhir).
   - `GITHUB_OWNER`: username atau organisasi pemilik repository.
   - `GITHUB_REPO`: nama repository, misalnya `videoku`.
   - `GITHUB_BRANCH`: biasanya `main`.

   Jika menggunakan custom domain, `SITE_ORIGIN` adalah origin custom domain, misalnya `https://video.contoh.com`.

4. Buat tiga secret berikut, satu perintah setiap kali. Terminal akan meminta nilainya:

   ```bash
   npx wrangler secret put GITHUB_TOKEN
   npx wrangler secret put ADMIN_PASSWORD
   npx wrangler secret put JWT_SECRET
   ```

   - `GITHUB_TOKEN`: fine-grained token dari Bagian 2.
   - `ADMIN_PASSWORD`: buat kata sandi admin yang panjang dan unik; jangan gunakan kata sandi akun lain.
   - `JWT_SECRET`: nilai acak panjang (minimal 32 byte). Kamu bisa membuatnya dengan `openssl rand -base64 48` jika OpenSSL tersedia. Masukkan hasilnya saat diminta oleh Wrangler.

5. Deploy Worker:

   ```bash
   npx wrangler deploy
   ```

6. Wrangler akan menampilkan URL Worker, biasanya seperti `https://videoku-api.NAMA-AKUN.workers.dev`. Salin URL itu.

7. Buka `assets/config.js` di repository GitHub, lalu isi `API_BASE_URL` dengan URL Worker, tanpa slash akhir:

   ```js
   window.VIDEOKU_CONFIG = {
     API_BASE_URL: "https://videoku-api.NAMA-AKUN.workers.dev"
   };
   ```

8. Commit perubahan `assets/config.js`. Tunggu GitHub Pages selesai menerbitkan perubahan.

9. Buka `https://USERNAME.github.io/videoku/admin.html`, login memakai `ADMIN_PASSWORD`, lalu tambahkan video.

## Bagian 4 — Menambahkan video

Di panel admin isi:

- **Judul:** judul yang ditampilkan di kartu dan halaman menonton.
- **URL video CDN MP4:** URL HTTPS langsung ke video yang dapat diakses publik. Pastikan provider CDN mengizinkan pemutaran lintas-origin (CORS) bila diperlukan.
- **URL thumbnail:** URL HTTPS ke gambar pratinjau JPG/PNG/WebP.
- **Kategori:** misalnya Hiburan, Edukasi, Musik, atau Travel.
- **Deskripsi:** opsional.

Klik **Simpan video ke GitHub**. Worker akan membaca data terbaru, menambahkan entri, lalu melakukan commit ke `data/videos.json`. Daftar video di website membaca data dari Worker, sehingga tidak harus menunggu halaman statis dibangun ulang untuk melihat data terbaru.

## Keamanan dan batasan

- Jangan pernah menaruh `GITHUB_TOKEN`, `ADMIN_PASSWORD`, atau `JWT_SECRET` di frontend/repository.
- Admin login memakai token HMAC bertanda tangan yang berlaku selama 6 jam; token disimpan di `sessionStorage` browser dan hilang saat sesi browser berakhir.
- CORS dibatasi ke origin website yang diatur pada `SITE_ORIGIN`. Pastikan nilainya tepat.
- Untuk penggunaan publik, aktifkan **rate limiting** pada endpoint `/api/login` melalui aturan Cloudflare WAF/Rate Limiting, dan gunakan kata sandi kuat. Implementasi dasar ini belum memiliki database pengguna, MFA, atau pembatasan login persisten.
- URL CDN harus HTTPS dan bisa diakses publik. Website tidak mengunggah atau menyimpan file video.
- GitHub Pages adalah hosting statis; Cloudflare Worker diperlukan untuk login dan commit metadata dengan aman.
- Perubahan bersamaan saat beberapa admin menyimpan video bisa menimbulkan konflik GitHub. Muat ulang daftar lalu coba lagi.
- Jika memakai URL CDN yang memerlukan header autentikasi khusus, pemutar HTML5 biasa mungkin tidak bisa memutarnya. Gunakan URL publik yang dapat diputar langsung.

## Troubleshooting

- **CORS error:** periksa `SITE_ORIGIN`; harus cocok dengan origin halaman yang membuka website, tanpa path repository.
- **GitHub 404:** periksa `GITHUB_OWNER`, `GITHUB_REPO`, `GITHUB_BRANCH`, dan keberadaan `data/videos.json` di branch itu.
- **GitHub 401/403:** periksa secret `GITHUB_TOKEN` dan izin Contents read/write. Jika token dirotasi, jalankan ulang `npx wrangler secret put GITHUB_TOKEN` lalu deploy ulang bila diperlukan.
- **API belum diatur:** isi `API_BASE_URL` di `assets/config.js`.
- **Video tidak dapat diputar:** uji URL CDN di tab browser baru; pastikan URL menunjuk ke media MP4 langsung dan provider CDN mengizinkan pemutaran.
- **Perubahan frontend belum terlihat:** tunggu deployment Pages selesai dan lakukan hard refresh (`Ctrl+F5`).

## Format `data/videos.json`

File ini diawali dengan `[]`. Setelah video ditambahkan, Worker akan mengisinya dalam format array, contoh struktur satu entri:

```json
[
  {
    "id": "id-otomatis",
    "title": "Contoh video",
    "videoUrl": "https://cdn.example.com/video.mp4",
    "thumbnail": "https://cdn.example.com/thumbnail.jpg",
    "category": "Edukasi",
    "description": "Deskripsi video",
    "createdAt": "2026-10-16T12:00:00.000Z"
  }
]
```
